﻿//Programmer: Simon(杨涵)
//StudentID: 1930026144
//Date: 2020.02.24
//Task No: Week_2_Task_1
/* Requirements:
•What are the different return for programs P1 and P2?
•What return statement is used for?
•Put the answers to the above questions at the end of
program P2 as comments . (P2 will be used in the
submission for Task 1)*/

#include <stdio.h>
int main() {
	printf("Hello\n");
	//return 1;
	printf("World\n");
	return 0;
}

/*
1) both p1 and p2 return 0 after performmed echo %errorlevel%
2) These returns just are used for pausing the program.
*/