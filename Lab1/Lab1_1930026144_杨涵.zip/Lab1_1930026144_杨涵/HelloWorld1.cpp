/*just an example*/
#include <stdio.h>
int main() {
	printf("Hello World\n");  //1st
	printf("Hello World\n");  //2nd
	printf("Hello World\n");  //3rd
	return 0;
}