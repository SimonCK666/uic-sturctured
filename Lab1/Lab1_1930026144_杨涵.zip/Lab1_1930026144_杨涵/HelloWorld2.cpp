/*Another example*/
#include <stdio.h>
int main() {
	printf("Hello World\nHello World\nHello World\n");
	return 0;
}